import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { addTodo } from '../services/action/todoAction';
import 'react-icons/fa';

export const Form = () => {

    const [inputText, setInputText] = useState("");
    const [category,setCategory] = useState("none");
    const dispatch = useDispatch();
    const categorySelect = ["No Category", "Anime", "Music", "Game", "Movies", "News"];
    const inputHandler = (e) =>{
        
       setInputText(e.target.value);
       //console.log(inputText);
      }
      const categoryHandler = (e) =>{
        setCategory(e.target.value);
      }
    const submitTodoHandler = (e)=>{
        console.log(inputText);
        e.preventDefault();
        if(inputText!==""){
          //console.log(category);
          const todo = {id: Math.random(), name: inputText, stat: false, category: category}; // category
          
          dispatch(addTodo(todo));
          setInputText("");
        }
        
        
    }

  return (
    <>
    <form >
      <input type="text" placeholder='Put your list item here' className="todo-input" value={inputText} onChange={inputHandler} />
       <button className="todo-button" type="submit" onClick={submitTodoHandler}>
        <i className="fas fa-plus-square"></i>
      </button>
      <div className="select">
        <select name="category" className="filter-todo" onChange={categoryHandler}>
        {
          categorySelect.map( (categry)=>{
            return <option value={categry}>{categry}</option>
          })
        }
        </select>
      </div>
    </form>
    </>
  )
}
